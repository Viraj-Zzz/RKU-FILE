Giriraj Food website organized files

HTML pages: index.html, about.html, menu.html, gallery.html, contact.html, feedback.html, signin.html
Shared stylesheet: style.css (page-specific styles are scoped by body class)
Assets: assets/logo.jpeg

Open index.html to start. All page-specific CSS files were merged into style.css.
Font Awesome remains loaded from its external CDN in the HTML pages.
