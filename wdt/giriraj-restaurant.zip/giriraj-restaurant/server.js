// ===============================================
// GIRIRAJ RESTAURANT - SIMPLE EXPRESS BACKEND
// ===============================================
// This server does 2 main jobs:
// 1. Serve our website files (HTML, CSS, JS, images)
// 2. Provide 2 API routes to save Feedback and Contact
//    messages into simple JSON files (no database).
// ===============================================

const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;

// ---------- MIDDLEWARE ----------
// Allows our frontend fetch() calls to talk to this backend
app.use(cors());

// Allows the server to understand JSON sent from the frontend forms
app.use(express.json());

// Serves all our static files (html, css, js, images) from the
// main project folder, so visiting http://localhost:3000/ works.
app.use(express.static(path.join(__dirname)));

// ---------- FILE PATHS ----------
const feedbackFilePath = path.join(__dirname, "data", "feedback.json");
const messagesFilePath = path.join(__dirname, "data", "messages.json");

// ---------- HELPER FUNCTIONS ----------

// Reads a JSON file and returns its content as a JS array.
// If the file is empty or has bad data, it safely returns [].
function readJSONFile(filePath) {
  try {
    const fileData = fs.readFileSync(filePath, "utf-8");
    if (!fileData) return [];
    return JSON.parse(fileData);
  } catch (error) {
    console.log("Could not read file, starting with empty list:", error.message);
    return [];
  }
}

// Writes a JS array back into a JSON file, nicely formatted.
function writeJSONFile(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

// ---------- API ROUTE: FEEDBACK ----------
// Saves feedback form data (name, email, rating, message) into feedback.json
app.post("/api/feedback", (req, res) => {
  const { name, email, rating, message } = req.body;

  // Basic backend validation (frontend already validates too)
  if (!name || !email || !rating || !message) {
    return res.status(400).json({
      success: false,
      error: "All fields are required.",
    });
  }

  // Read existing feedback list
  const feedbackList = readJSONFile(feedbackFilePath);

  // Create a new feedback entry
  const newFeedback = {
    id: Date.now(),
    name,
    email,
    rating,
    message,
    date: new Date().toISOString(),
  };

  // Add new entry and save
  feedbackList.push(newFeedback);
  writeJSONFile(feedbackFilePath, feedbackList);

  console.log("New feedback saved:", newFeedback);

  res.json({
    success: true,
    message: "Thank you! Your feedback has been submitted.",
  });
});

// ---------- API ROUTE: CONTACT ----------
// Saves contact form data (name, email, subject, message) into messages.json
app.post("/api/contact", (req, res) => {
  const { name, email, subject, message } = req.body;

  // Basic backend validation
  if (!name || !email || !subject || !message) {
    return res.status(400).json({
      success: false,
      error: "All fields are required.",
    });
  }

  // Read existing messages list
  const messagesList = readJSONFile(messagesFilePath);

  // Create a new message entry
  const newMessage = {
    id: Date.now(),
    name,
    email,
    subject,
    message,
    date: new Date().toISOString(),
  };

  // Add new entry and save
  messagesList.push(newMessage);
  writeJSONFile(messagesFilePath, messagesList);

  console.log("New contact message saved:", newMessage);

  res.json({
    success: true,
    message: "Your message has been sent successfully!",
  });
});

// ---------- START SERVER ----------
app.listen(PORT, () => {
  console.log(`Giriraj Restaurant server running at http://localhost:${PORT}`);
});
