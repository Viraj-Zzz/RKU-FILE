This folder is for optional real food images (e.g. paneer.jpg). The site currently uses emoji icons and works fine without any images here.
