# Giriraj – Pure Vegetarian Restaurant Website

A simple, beginner-friendly restaurant website built with **HTML, CSS,
vanilla JavaScript**, and a **Node.js + Express** backend that stores
data in plain **JSON files** (no database needed).

## Project Structure

```
giriraj-restaurant/
├── index.html          Home page
├── menu.html            Menu page (with category filter)
├── feedback.html         Feedback form
├── contact.html          Contact form
├── css/
│   └── style.css         All styling
├── js/
│   ├── main.js           Mobile nav menu (shared)
│   ├── menu.js           Menu category filter logic
│   ├── feedback.js        Feedback form validation + submit
│   └── contact.js         Contact form validation + submit
├── data/
│   ├── feedback.json      Feedback gets saved here
│   └── messages.json      Contact messages get saved here
├── server.js             Express backend
├── package.json
└── README.md
```

## How to Run the Project

### 1. Install Node.js
Download and install Node.js (LTS version) from https://nodejs.org
if you don't already have it.

### 2. Open the project folder
Open the `giriraj-restaurant` folder in VS Code, then open a terminal
inside VS Code (Terminal → New Terminal).

### 3. Install dependencies
In the terminal, run:

```
npm install
```

This installs `express` and `cors`, which the backend needs.

### 4. Start the server
Run:

```
node server.js
```

You should see:

```
Giriraj Restaurant server running at http://localhost:3000
```

### 5. Open the website
Open your browser and go to:

```
http://localhost:3000
```

That's it! The home page, menu, feedback, and contact pages are all
served by this one server.

## How to Test Each Feature

### Test the Menu Filter
1. Go to the **Menu** page.
2. Click any category button (e.g. "Starters", "Desserts").
3. Only dishes from that category should appear.
4. Click "All" to see every dish again.

### Test the Feedback Form
1. Go to the **Feedback** page.
2. Try submitting the form empty — you should see red error messages.
3. Fill in all fields correctly and click **Submit Feedback**.
4. You should see: "Thank you! Your feedback has been submitted."
5. Check the file `data/feedback.json` — your new feedback will be
   saved there.

### Test the Contact Form
1. Go to the **Contact** page.
2. Try submitting the form empty — you should see red error messages.
3. Fill in all fields correctly and click **Send Message**.
4. You should see: "Your message has been sent successfully!"
5. Check the file `data/messages.json` — your new message will be
   saved there.

## Notes
- No database is used — all form data is stored in simple JSON files
  inside the `data/` folder.
- The Google Map on the Contact page is a placeholder box (no API key
  required).
- Food images use simple emoji icons instead of external image files,
  so the site works perfectly offline with no broken images.
- To stop the server, go back to the terminal and press `Ctrl + C`.
