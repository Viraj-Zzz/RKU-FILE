// =========================================================
// FEEDBACK.JS - Validates and submits the feedback form
// =========================================================

// Grab the form and the message box
const feedbackForm = document.getElementById("feedbackForm");
const formMessage = document.getElementById("formMessage");

// Grab all the input fields we need to validate
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const ratingInput = document.getElementById("rating");
const messageInput = document.getElementById("message");

// A simple helper to check if an email looks valid
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// A helper to show/hide a single error message under a field
function toggleError(errorId, show) {
  const errorEl = document.getElementById(errorId);
  errorEl.style.display = show ? "block" : "none";
}

feedbackForm.addEventListener("submit", async (event) => {
  // Stop the form from refreshing the page
  event.preventDefault();

  let isValid = true;

  // ---------- VALIDATION ----------
  if (nameInput.value.trim() === "") {
    toggleError("nameError", true);
    isValid = false;
  } else {
    toggleError("nameError", false);
  }

  if (!isValidEmail(emailInput.value.trim())) {
    toggleError("emailError", true);
    isValid = false;
  } else {
    toggleError("emailError", false);
  }

  if (ratingInput.value === "") {
    toggleError("ratingError", true);
    isValid = false;
  } else {
    toggleError("ratingError", false);
  }

  if (messageInput.value.trim() === "") {
    toggleError("messageError", true);
    isValid = false;
  } else {
    toggleError("messageError", false);
  }

  // If any field is invalid, stop here and don't send the request
  if (!isValid) {
    formMessage.className = "form-message error";
    formMessage.textContent = "Please fill in all required fields correctly.";
    return;
  }

  // ---------- SEND DATA TO BACKEND ----------
  const feedbackData = {
    name: nameInput.value.trim(),
    email: emailInput.value.trim(),
    rating: ratingInput.value,
    message: messageInput.value.trim(),
  };

  try {
    const response = await fetch("/api/feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(feedbackData),
    });

    const result = await response.json();

    if (response.ok && result.success) {
      formMessage.className = "form-message success";
      formMessage.textContent = result.message; // "Thank you! Your feedback has been submitted."
      feedbackForm.reset();
    } else {
      formMessage.className = "form-message error";
      formMessage.textContent = result.error || "Something went wrong. Please try again.";
    }
  } catch (error) {
    // This runs if the server is not running or there is a network error
    formMessage.className = "form-message error";
    formMessage.textContent = "Could not connect to the server. Please try again later.";
    console.error("Feedback submit error:", error);
  }
});
