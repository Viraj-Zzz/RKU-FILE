// =========================================================
// MAIN.JS - Shared script used on every page
// Handles the mobile navigation menu (hamburger button)
// =========================================================

// Get the button and the nav links list from the page
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

// When the hamburger button is clicked, show/hide the nav links
if (menuToggle && navLinks) {
  menuToggle.addEventListener("click", () => {
    navLinks.classList.toggle("show");
  });
}
