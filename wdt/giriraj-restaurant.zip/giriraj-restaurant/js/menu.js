// =========================================================
// MENU.JS - Handles the category filter buttons on menu.html
// =========================================================

// Get all filter buttons and all menu items on the page
const filterButtons = document.querySelectorAll(".filter-btn");
const menuItems = document.querySelectorAll(".menu-item");
const categoryHeadings = document.querySelectorAll(".category-heading");

// Loop through every filter button and listen for clicks
filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    // Get the category from the button's data-category attribute
    const selectedCategory = button.getAttribute("data-category");

    // Remove "active" class from all buttons, then add it to the clicked one
    filterButtons.forEach((btn) => btn.classList.remove("active"));
    button.classList.add("active");

    // Show or hide each menu item based on the selected category
    menuItems.forEach((item) => {
      const itemCategory = item.getAttribute("data-category");

      if (selectedCategory === "all" || itemCategory === selectedCategory) {
        item.style.display = "block";
      } else {
        item.style.display = "none";
      }
    });

    // Show or hide each category heading (like "Starters", "Main Course")
    categoryHeadings.forEach((heading) => {
      const headingGroup = heading.getAttribute("data-group");

      if (selectedCategory === "all" || headingGroup === selectedCategory) {
        heading.style.display = "block";
      } else {
        heading.style.display = "none";
      }
    });
  });
});
