// =========================================================
// CONTACT.JS - Validates and submits the contact form
// =========================================================

const contactForm = document.getElementById("contactForm");
const formMessage = document.getElementById("formMessage");

const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const subjectInput = document.getElementById("subject");
const messageInput = document.getElementById("message");

// A simple helper to check if an email looks valid
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// A helper to show/hide a single error message under a field
function toggleError(errorId, show) {
  const errorEl = document.getElementById(errorId);
  errorEl.style.display = show ? "block" : "none";
}

contactForm.addEventListener("submit", async (event) => {
  // Stop the form from refreshing the page
  event.preventDefault();

  let isValid = true;

  // ---------- VALIDATION ----------
  if (nameInput.value.trim() === "") {
    toggleError("nameError", true);
    isValid = false;
  } else {
    toggleError("nameError", false);
  }

  if (!isValidEmail(emailInput.value.trim())) {
    toggleError("emailError", true);
    isValid = false;
  } else {
    toggleError("emailError", false);
  }

  if (subjectInput.value.trim() === "") {
    toggleError("subjectError", true);
    isValid = false;
  } else {
    toggleError("subjectError", false);
  }

  if (messageInput.value.trim() === "") {
    toggleError("messageError", true);
    isValid = false;
  } else {
    toggleError("messageError", false);
  }

  if (!isValid) {
    formMessage.className = "form-message error";
    formMessage.textContent = "Please fill in all required fields correctly.";
    return;
  }

  // ---------- SEND DATA TO BACKEND ----------
  const contactData = {
    name: nameInput.value.trim(),
    email: emailInput.value.trim(),
    subject: subjectInput.value.trim(),
    message: messageInput.value.trim(),
  };

  try {
    const response = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(contactData),
    });

    const result = await response.json();

    if (response.ok && result.success) {
      formMessage.className = "form-message success";
      formMessage.textContent = result.message; // "Your message has been sent successfully!"
      contactForm.reset();
    } else {
      formMessage.className = "form-message error";
      formMessage.textContent = result.error || "Something went wrong. Please try again.";
    }
  } catch (error) {
    formMessage.className = "form-message error";
    formMessage.textContent = "Could not connect to the server. Please try again later.";
    console.error("Contact submit error:", error);
  }
});
